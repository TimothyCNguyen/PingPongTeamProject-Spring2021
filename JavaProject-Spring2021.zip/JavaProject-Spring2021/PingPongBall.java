package project;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.Random;

public class PingPongBall implements Runnable {

	int x;
        int y;
        int xDirection;
        int yDirection;
	int p1Score;
        int p2Score;
        int maxScore;
	int randomXDirection;
        int randomYDirection;
        int randomDirection;
        
	static PingPongPaddle paddle1 = new PingPongPaddle(5, 335, 1);
	static PingPongPaddle paddle2 = new PingPongPaddle(980, 335, 2);
	
	Rectangle ball;

	public PingPongBall(int maxScore){
		this.maxScore = maxScore;
            
                p1Score = 0;
                p2Score = 0;
		
                resetBallPosition();
	}
        
        public void setMaxScore(int maxScore){
		this.maxScore = maxScore;
	}
	public int getXDirection(){
		return xDirection;
	}
	public int getYDirection(){
		return yDirection;
	}
	public void setXDirection(int xDirection){
		this.xDirection = xDirection;
	}
	public void setYDirection(int yDirection){
		this.yDirection = yDirection;
	}
        
        public void setXDirectionRandom(){
		Random random = new Random();
                randomXDirection = random.nextInt(4);
            switch (randomXDirection) {
                case 0:
                    setXDirection(-3);
                    break;
                case 1:
                    setXDirection(-2);
                    break;
                case 2:
                    setXDirection(2);
                    break;
                default:
                    setXDirection(3);
                    break;
            }
	}
	public void setYDirectionRandom(){
                Random random = new Random();
                randomYDirection = random.nextInt(4);
            switch (randomYDirection) {
                case 0:
                    setYDirection(-3);
                    break;
                case 1:
                    setYDirection(-2);
                    break;
                case 2:
                    setYDirection(2);
                    break;
                default:
                    setYDirection(3);
                    break;
            }
	}
        
        public void startingDirection() {
                Random random = new Random();
                randomDirection = random.nextInt(2);
                if (randomDirection == 0) {
                setXDirection(-2);
                setYDirection(0);
                }
                else {
                setXDirection(2);
                setYDirection(0);
                }
        }

	public void draw(Graphics g) {
		g.setColor(Color.DARK_GRAY);
		g.fillRect(ball.x, ball.y, ball.width, ball.height);
	}
        
	public void paddleCollision(){
        if(ball.intersects(paddle1.paddle)) {
            Random random = new Random();
            randomXDirection = random.nextInt(2);
            if (randomXDirection == 0) {
            setXDirection(2);
                }
            else {
            setXDirection(3);
                }
            setYDirectionRandom();
            }
        if(ball.intersects(paddle2.paddle)) {
            Random random = new Random();
            randomXDirection = random.nextInt(2);
            if (randomXDirection == 0) {
            setXDirection(-2);
                }
            else {
            setXDirection(-3);
                }
            setYDirectionRandom();
            }
        }
        
        public void resetBallPosition() {
                    this.x = 500;
                    this.y = 400;
                startingDirection();
		ball = new Rectangle(this.x, this.y, 15, 15);
        }
        
	public void ballMovement() {
		paddleCollision();
		ball.x += xDirection;
		ball.y += yDirection;
                
		//bounce the ball when it hits the edge of the screen
		if (ball.x <= 0) {
                    //Prevents another point to be added.
			setXDirection(2);
			p2Score += 1;
                        
			resetBallPosition();
	}
		if (ball.x >= 985) {
                    //Prevents another point to be added.
			setXDirection(-2);
			p1Score += 1;
                        
                        resetBallPosition();
		}
		if (ball.y <= 15 || ball.y >= 785) {
                    //Reverses direction for y
			setYDirection(getYDirection()*-1);
		}
	}
	
	@Override
	public void run() {
		try {
			while(true) {
				ballMovement();
				Thread.sleep(8);
			}
		}catch(Exception e) { System.err.println(e.getMessage()); }
	}
}