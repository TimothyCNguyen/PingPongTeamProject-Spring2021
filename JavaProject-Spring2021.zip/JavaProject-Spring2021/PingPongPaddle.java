package project;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;


public class PingPongPaddle implements Runnable{
	
	int x, y, yPaddleDirection, paddleNumber;
	
	Rectangle paddle;
	
	public PingPongPaddle(int x, int y, int paddleID){
		this.x = x;
		this.y = y;
		this.paddleNumber = paddleID;
		paddle = new Rectangle(x, y, 15, 75);
		}
		
	public void pressKey(KeyEvent e) {
		switch(paddleNumber) {
		default:
			System.out.println("Please enter a Valid ID in paddle contructor");
			break;
		case 1:
			if(e.getKeyCode() == KeyEvent.VK_W) {
				setYPaddleDirection(-5);
                        }
			if(e.getKeyCode() == KeyEvent.VK_S) {
				setYPaddleDirection(5);
			}
			break;
		case 2:
			if(e.getKeyCode() == KeyEvent.VK_UP) {
				setYPaddleDirection(-5);
			}
			if(e.getKeyCode() == KeyEvent.VK_DOWN) {
				setYPaddleDirection(5);
			}
			break;
	}
	}
	
	public void releasedKey(KeyEvent e) {
		switch(paddleNumber) {
		default:
			System.out.println("Please enter a Valid ID in paddle contructor");
			break;
		case 1:
		if(e.getKeyCode() == e.VK_W) {
			setYPaddleDirection(0);
		}
		if(e.getKeyCode() == e.VK_S) {
			setYPaddleDirection(0);
		}
		break;
		case 2:
			
		if(e.getKeyCode() == e.VK_UP) {
			setYPaddleDirection(0);
		}
		if(e.getKeyCode() == e.VK_DOWN) {
			setYPaddleDirection(0);
		}
		break;
	}
	}
	public void setYPaddleDirection(int yDir) {
		yPaddleDirection = yDir;
	}
	
	public void movementBound() {
	 	paddle.y += yPaddleDirection;
	 	if (paddle.y <= 30) {
	 		paddle.y = 30;
                }
	 	if (paddle.y >= 720) {
	 		paddle.y = 720;
                }
	}
        
	public void draw(Graphics g) {
		switch(paddleNumber) {
		default:
			System.out.println("Please enter a Valid ID in paddle contructor");
			break;
		case 1:
			g.setColor(Color.red);
			g.fillRect(paddle.x, paddle.y, paddle.width, paddle.height);
			break;
		case 2:
			g.setColor(Color.green);
			g.fillRect(paddle.x, paddle.y, paddle.width, paddle.height);
			break;
		}
	}
	@Override
	public void run() {
		try {
			while(true) {
				movementBound();
				Thread.sleep(7);
			}
		} catch(Exception e) { System.err.println(e.getMessage()); }
	}
}