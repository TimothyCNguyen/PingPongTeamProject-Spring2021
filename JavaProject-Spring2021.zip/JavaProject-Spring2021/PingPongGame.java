package project;

import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.*;
import java.awt.Image;

public class PingPongGame extends JFrame {
	
	int gWidth = 1000;
	int gHeight = 800;
	Dimension screenSize = new Dimension(gWidth, gHeight);
	
	Image dbImage;
	Graphics dbGraphics;

	static PingPongBall b = new PingPongBall(3);
	
	public PingPongGame() {
		this.setTitle("Ping-Pong");
		this.setSize(screenSize);
		this.setResizable(false);
		this.setVisible(true);
		this.setBackground(Color.WHITE);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.addKeyListener(new AL());
	}
	
	@Override
	public void paint(Graphics g) {
		dbImage = createImage(getWidth(), getHeight());
		dbGraphics = dbImage.getGraphics();
		drawObjects(dbGraphics);
		g.drawImage(dbImage, 0, 0, this);
	}
	
	public void drawObjects(Graphics g) {
		b.draw(g);
		b.paddle1.draw(g);
		b.paddle2.draw(g);	
		g.setColor(Color.BLACK);
		g.drawString(""+b.p1Score, 215, 50);
		g.drawString(""+b.p2Score, 785, 50);	
                g.drawString("Maximum score: " + b.maxScore, 450, 50);
                recordScores(g);    
		repaint();
	}
        
        public void recordScores(Graphics g) {
            if (b.p1Score == b.maxScore) {
                    b.setXDirection(0);
                    b.setYDirection(0);
                //resets scores
                b.p1Score = 0;
                b.p2Score = 0;
                new Player1Win().setVisible(true);
                    }
            if (b.p2Score == b.maxScore) {
                    b.setXDirection(0);
                    b.setYDirection(0);
                //resets scores
                b.p1Score = 0;
                b.p2Score = 0;
                new Player2Win().setVisible(true);
                    }
        }
        
	public class AL extends KeyAdapter {
		@Override
		public void keyPressed(KeyEvent e) {
			b.paddle1.pressKey(e);
			b.paddle2.pressKey(e);
		}
		@Override
		public void keyReleased(KeyEvent e) {
			b.paddle1.releasedKey(e);
			b.paddle2.releasedKey(e);
		}	
	}
}